package com.example.test_cursor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ScrollView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import javax.microedition.khronos.egl.EGLDisplay;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    private DatabaseReference mDatabase;

    public void ClickOver (View v){

        mDatabase = FirebaseDatabase.getInstance().getReference();
        //
        String t1,t2,t3,t4,t5,t6,t7,t8,t9;
        EditText text1 = (EditText) findViewById(R.id.editText2);
        EditText text2 = (EditText) findViewById(R.id.editText4);
        EditText text3 = (EditText) findViewById(R.id.editText3);
        EditText text4 = (EditText) findViewById(R.id.editText5);
        EditText text5 = (EditText) findViewById(R.id.editText6);
        EditText text6 = (EditText) findViewById(R.id.editText11);
        EditText text7 = (EditText) findViewById(R.id.editText7);
        EditText text8 = (EditText) findViewById(R.id.editText8);
        EditText text9 = (EditText) findViewById(R.id.editText9);
        //
        t1 = text1.getText().toString();
        t2 = text2.getText().toString();
        t3 = text3.getText().toString();
        t4 = text4.getText().toString();
        t5 = text5.getText().toString();
        t6 = text6.getText().toString();
        t7 = text7.getText().toString();
        t8 = text8.getText().toString();
        t9 = text9.getText().toString();
        //
        String fullTest = t1 + "\n"+  t2 + "\n"+ t3 + "\n"+ t4 + "\n"+ t5 + "\n"+ t6 + "\n"+ t7 + "\n"+ t8 + "\n"+ t9;
        mDatabase.setValue(fullTest);



    }

}
